//For Localhost use: "http://10.0.2.2:8000/"
//For Deploying on current Network: "http://PC IP from ipconfig:5000/"

const String SERVER_URL = "http://192.168.1.105:5000/";
