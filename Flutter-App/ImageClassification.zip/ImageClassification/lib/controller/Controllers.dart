class MyStateController {
  Function() disable;
  Function() enable;
  // ignore: non_constant_identifier_names
  String Text = "";
}
